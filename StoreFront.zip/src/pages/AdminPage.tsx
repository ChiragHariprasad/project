import React from 'react';
import AdminItemList from '../components/admin/AdminItemList';

const AdminPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto">
      <AdminItemList />
    </div>
  );
};

export default AdminPage;
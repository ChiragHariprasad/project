import React, { useState } from 'react';
import InventoryList from '../components/inventory/InventoryList';

const InventoryPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto">
      <InventoryList />
    </div>
  );
};

export default InventoryPage;
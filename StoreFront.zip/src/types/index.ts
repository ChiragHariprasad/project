// Type definitions for the application

export interface User {
  uid: string;
  isAdmin: boolean;
}

export interface InventoryItem {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  image: string;
  category: string;
  nextRestock: string; // ISO date string
}

export interface CartItem {
  item: InventoryItem;
  quantity: number;
}

export interface ExtensionPoint {
  id: string;
  component: React.ComponentType<any>;
}
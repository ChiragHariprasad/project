import React, { createContext, useContext, useState, useEffect } from 'react';
import { InventoryItem, CartItem } from '../types';
import sampleInventory from '../data/sampleInventory';

interface InventoryContextType {
  inventory: InventoryItem[];
  cart: CartItem[];
  addToCart: (item: InventoryItem, quantity: number) => void;
  removeFromCart: (itemId: string) => void;
  updateCartItemQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  checkout: () => void;
  addInventoryItem: (item: InventoryItem) => void;
  updateInventoryItem: (item: InventoryItem) => void;
  deleteInventoryItem: (itemId: string) => void;
}

const InventoryContext = createContext<InventoryContextType | undefined>(undefined);

export const useInventory = () => {
  const context = useContext(InventoryContext);
  if (!context) {
    throw new Error('useInventory must be used within an InventoryProvider');
  }
  return context;
};

export const InventoryProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);

  // Initialize with sample data or load from localStorage
  useEffect(() => {
    const storedInventory = localStorage.getItem('inventory');
    if (storedInventory) {
      setInventory(JSON.parse(storedInventory));
    } else {
      setInventory(sampleInventory);
      localStorage.setItem('inventory', JSON.stringify(sampleInventory));
    }

    const storedCart = localStorage.getItem('cart');
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  // Save inventory to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('inventory', JSON.stringify(inventory));
  }, [inventory]);

  const addToCart = (item: InventoryItem, quantity: number) => {
    const existingCartItem = cart.find(cartItem => cartItem.item.id === item.id);
    
    if (existingCartItem) {
      setCart(cart.map(cartItem => 
        cartItem.item.id === item.id 
          ? { ...cartItem, quantity: cartItem.quantity + quantity } 
          : cartItem
      ));
    } else {
      setCart([...cart, { item, quantity }]);
    }
  };

  const removeFromCart = (itemId: string) => {
    setCart(cart.filter(cartItem => cartItem.item.id !== itemId));
  };

  const updateCartItemQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(itemId);
    } else {
      setCart(cart.map(cartItem => 
        cartItem.item.id === itemId 
          ? { ...cartItem, quantity } 
          : cartItem
      ));
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  const checkout = () => {
    // Update inventory stock based on purchased items
    const updatedInventory = inventory.map(item => {
      const cartItem = cart.find(ci => ci.item.id === item.id);
      if (cartItem) {
        return {
          ...item,
          stock: Math.max(0, item.stock - cartItem.quantity)
        };
      }
      return item;
    });
    
    setInventory(updatedInventory);
    clearCart();
  };

  const addInventoryItem = (item: InventoryItem) => {
    setInventory([...inventory, item]);
  };

  const updateInventoryItem = (updatedItem: InventoryItem) => {
    setInventory(inventory.map(item => 
      item.id === updatedItem.id ? updatedItem : item
    ));
  };

  const deleteInventoryItem = (itemId: string) => {
    setInventory(inventory.filter(item => item.id !== itemId));
  };

  return (
    <InventoryContext.Provider value={{
      inventory,
      cart,
      addToCart,
      removeFromCart,
      updateCartItemQuantity,
      clearCart,
      checkout,
      addInventoryItem,
      updateInventoryItem,
      deleteInventoryItem
    }}>
      {children}
    </InventoryContext.Provider>
  );
};
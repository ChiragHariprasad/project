import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (uid: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (password: string) => Promise<{ success: boolean; uid?: string }>;
  isLoading: boolean;
  error: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Check for existing session
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setIsLoading(false);
  }, []);

  // Generate random UID for new users
  const generateUID = (): string => {
    return Math.random().toString(36).substring(2, 10);
  };

  const login = async (uid: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Admin login
      if (uid === 'admin' && password === '@123') {
        const adminUser: User = { uid: 'admin', isAdmin: true };
        setUser(adminUser);
        localStorage.setItem('user', JSON.stringify(adminUser));
        return true;
      }
      
      // Regular user login
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const foundUser = users.find((u: any) => u.uid === uid && u.password === password);
      
      if (foundUser) {
        const loggedInUser: User = { uid: foundUser.uid, isAdmin: false };
        setUser(loggedInUser);
        localStorage.setItem('user', JSON.stringify(loggedInUser));
        return true;
      } else {
        setError('Invalid credentials');
        return false;
      }
    } catch (err) {
      setError('An error occurred during login');
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (password: string): Promise<{ success: boolean; uid?: string }> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const uid = generateUID();
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      
      users.push({ uid, password });
      localStorage.setItem('users', JSON.stringify(users));
      
      return { success: true, uid };
    } catch (err) {
      setError('An error occurred during registration');
      return { success: false };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, register, isLoading, error }}>
      {children}
    </AuthContext.Provider>
  );
};